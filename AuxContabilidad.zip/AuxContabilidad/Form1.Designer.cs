﻿namespace AuxContabilidad
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.pbProgreso = new System.Windows.Forms.ProgressBar();
            this.lblTitulo = new System.Windows.Forms.Label();
            this.btnFindExcel = new System.Windows.Forms.Button();
            this.txtRutaExcel = new System.Windows.Forms.TextBox();
            this.txtRutaFacturas = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.btnFindFolder = new System.Windows.Forms.Button();
            this.fbdFindFacturas = new System.Windows.Forms.FolderBrowserDialog();
            this.ofdFindExcel = new System.Windows.Forms.OpenFileDialog();
            this.btnProceder = new System.Windows.Forms.Button();
            this.lblPorcentaje = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // pbProgreso
            // 
            this.pbProgreso.Location = new System.Drawing.Point(18, 326);
            this.pbProgreso.Margin = new System.Windows.Forms.Padding(4);
            this.pbProgreso.Name = "pbProgreso";
            this.pbProgreso.Size = new System.Drawing.Size(496, 31);
            this.pbProgreso.TabIndex = 5;
            // 
            // lblTitulo
            // 
            this.lblTitulo.AutoSize = true;
            this.lblTitulo.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitulo.Location = new System.Drawing.Point(13, 34);
            this.lblTitulo.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTitulo.Name = "lblTitulo";
            this.lblTitulo.Size = new System.Drawing.Size(218, 25);
            this.lblTitulo.TabIndex = 4;
            this.lblTitulo.Text = "Seleccione el archivo";
            // 
            // btnFindExcel
            // 
            this.btnFindExcel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFindExcel.Location = new System.Drawing.Point(469, 76);
            this.btnFindExcel.Margin = new System.Windows.Forms.Padding(4);
            this.btnFindExcel.Name = "btnFindExcel";
            this.btnFindExcel.Size = new System.Drawing.Size(45, 34);
            this.btnFindExcel.TabIndex = 3;
            this.btnFindExcel.Text = "...";
            this.btnFindExcel.UseVisualStyleBackColor = true;
            this.btnFindExcel.Click += new System.EventHandler(this.btnFindExcel_Click);
            // 
            // txtRutaExcel
            // 
            this.txtRutaExcel.Location = new System.Drawing.Point(18, 76);
            this.txtRutaExcel.Multiline = true;
            this.txtRutaExcel.Name = "txtRutaExcel";
            this.txtRutaExcel.ReadOnly = true;
            this.txtRutaExcel.Size = new System.Drawing.Size(444, 34);
            this.txtRutaExcel.TabIndex = 6;
            // 
            // txtRutaFacturas
            // 
            this.txtRutaFacturas.Location = new System.Drawing.Point(18, 174);
            this.txtRutaFacturas.Multiline = true;
            this.txtRutaFacturas.Name = "txtRutaFacturas";
            this.txtRutaFacturas.ReadOnly = true;
            this.txtRutaFacturas.Size = new System.Drawing.Size(444, 34);
            this.txtRutaFacturas.TabIndex = 9;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(13, 132);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(340, 25);
            this.label1.TabIndex = 8;
            this.label1.Text = "Seleccione la carpeta de Facturas";
            // 
            // btnFindFolder
            // 
            this.btnFindFolder.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnFindFolder.Location = new System.Drawing.Point(469, 174);
            this.btnFindFolder.Margin = new System.Windows.Forms.Padding(4);
            this.btnFindFolder.Name = "btnFindFolder";
            this.btnFindFolder.Size = new System.Drawing.Size(45, 34);
            this.btnFindFolder.TabIndex = 7;
            this.btnFindFolder.Text = "...";
            this.btnFindFolder.UseVisualStyleBackColor = true;
            this.btnFindFolder.Click += new System.EventHandler(this.btnFindFolder_Click);
            // 
            // ofdFindExcel
            // 
            this.ofdFindExcel.FileName = "openFileDialog1";
            // 
            // btnProceder
            // 
            this.btnProceder.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnProceder.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnProceder.Location = new System.Drawing.Point(154, 233);
            this.btnProceder.Margin = new System.Windows.Forms.Padding(4);
            this.btnProceder.Name = "btnProceder";
            this.btnProceder.Size = new System.Drawing.Size(233, 51);
            this.btnProceder.TabIndex = 10;
            this.btnProceder.Text = "Ayudame Goku!!!";
            this.btnProceder.UseVisualStyleBackColor = false;
            this.btnProceder.Click += new System.EventHandler(this.btnProceder_Click);
            // 
            // lblPorcentaje
            // 
            this.lblPorcentaje.AutoSize = true;
            this.lblPorcentaje.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPorcentaje.Location = new System.Drawing.Point(249, 297);
            this.lblPorcentaje.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPorcentaje.Name = "lblPorcentaje";
            this.lblPorcentaje.Size = new System.Drawing.Size(31, 25);
            this.lblPorcentaje.TabIndex = 11;
            this.lblPorcentaje.Text = "%";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(542, 370);
            this.Controls.Add(this.lblPorcentaje);
            this.Controls.Add(this.btnProceder);
            this.Controls.Add(this.txtRutaFacturas);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnFindFolder);
            this.Controls.Add(this.txtRutaExcel);
            this.Controls.Add(this.pbProgreso);
            this.Controls.Add(this.lblTitulo);
            this.Controls.Add(this.btnFindExcel);
            this.Name = "Form1";
            this.Text = "Aux. Contabilidad";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ProgressBar pbProgreso;
        private System.Windows.Forms.Label lblTitulo;
        private System.Windows.Forms.Button btnFindExcel;
        private System.Windows.Forms.TextBox txtRutaExcel;
        private System.Windows.Forms.TextBox txtRutaFacturas;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnFindFolder;
        private System.Windows.Forms.FolderBrowserDialog fbdFindFacturas;
        private System.Windows.Forms.OpenFileDialog ofdFindExcel;
        private System.Windows.Forms.Button btnProceder;
        private System.Windows.Forms.Label lblPorcentaje;
    }
}

