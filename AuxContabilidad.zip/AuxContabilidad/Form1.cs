﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using Excel = Microsoft.Office.Interop.Excel;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;

namespace AuxContabilidad
{
    public partial class Form1 : Form
    {
        string strRutaExcelOrig = "", strRutaExcel = "", strRutaFacturas = "", strRutaFacturasResultado = "", strRutaActualSub = "";
        string strFactura = "", strPoliza = "", strPolizaBuscar = "", strGrupo = "",strGrupoAux="",strRutaAux="", strRutaAuxPoliza = "", strRutaArchivo="",strNombreExcel="",strMes="",strEncontrado="";
        int intCantidadRegistros = 0, intColFactura=0,intColPoliza=0,intColGrupo=0,intColMes=0,intColEncontrado=0,intConteo=0;
        bool bValidacion = true;
        DateTime dtFechaArchivoYYYYMM;
        DirectoryInfo diDir,dirDirFacturas;
        Task tTarea;
        FileInfo[] fiArchivos;
        WebClient webclient = new WebClient();
        public Form1()
        {
            InitializeComponent();
        }
        void AumentarProgreso(int intPorcentaje)
        {
            Invoke(new Action(() => pbProgreso.Value = intPorcentaje));
            Invoke(new Action(() => lblPorcentaje.Text = intPorcentaje.ToString() + " %"));
        }
        private void btnFindExcel_Click(object sender, EventArgs e)
        {
            ofdFindExcel.Filter = "Excel Files|*.xlsx";
            if (ofdFindExcel.ShowDialog() == DialogResult.OK)
            {
                txtRutaExcel.Text = ofdFindExcel.FileName;
                strNombreExcel = ofdFindExcel.SafeFileName;
            }
        }

        private void btnFindFolder_Click(object sender, EventArgs e)
        {
            if (fbdFindFacturas.ShowDialog() == DialogResult.OK)
            {
                txtRutaFacturas.Text = fbdFindFacturas.SelectedPath;
            }
        }

        private async void btnProceder_Click(object sender, EventArgs e)
        {
            if (Validar())
            {
                strRutaExcelOrig = txtRutaExcel.Text;
                strRutaFacturas = txtRutaFacturas.Text;

                if (CrearRutaResultado())
                {
                    if (CopiarArchivoExcel())
                    {
                        tTarea = new Task(() => Procesar());
                        tTarea.Start();
                        await tTarea;

                        Process.Start(new ProcessStartInfo("explorer.exe", "/select, \"" + strRutaActualSub));
                        MessageBox.Show("Termino");
                    }
                }
            }
            else
            {
                MessageBox.Show("Verifique las rutas");
            }
        }

        bool Validar()
        {
            bValidacion = true;
            if (txtRutaExcel.Text.CompareTo("") == 0 || txtRutaFacturas.Text.CompareTo("") == 0)
            {
                bValidacion = false;
            }
            return bValidacion;
        }

        bool CrearRutaResultado()
        {
            bValidacion = true;
            try
            {
                strRutaFacturasResultado = strRutaFacturas + "\\RESULTADO";
                diDir = new DirectoryInfo(strRutaFacturasResultado);

                if (!diDir.Exists) //Si el directorio no existe, lo creo
                {
                    diDir.Create();
                }
            }
            catch (Exception ex)
            {
                bValidacion = false;
                MessageBox.Show(ex.ToString());
            }
            return bValidacion;
        }

        bool CopiarArchivoExcel()
        {
            bValidacion = true;
            try
            {
                strRutaAux = strRutaFacturasResultado + "\\" + strNombreExcel;
                if (!File.Exists(strRutaAux))
                {
                    File.Copy(strRutaExcelOrig, strRutaAux);
                }
                strRutaExcel = strRutaAux;
                //MessageBox.Show(strRutaExcel);
            }
            catch (Exception)
            {
                bValidacion = false;
            }
            return bValidacion;
        }

        async Task<Thread> Procesar()
        {
            //Creo el objeto de el archivo excel
            Excel.Application oXL = new Excel.Application();
            //Lo oculto porque por defecto lo deja abierto
            oXL.Visible = false;
            //Abro el archivo de la ruta
            Excel._Workbook wb = oXL.Workbooks.Open(strRutaExcel);
            //Me coloco en su primer hoja
            Excel._Worksheet excelSheet = wb.ActiveSheet;
            bool recorrer = true;
            //dynamic dynRenglonActual = "";
            intCantidadRegistros = excelSheet.UsedRange.Rows.Count - 1;
            intCantidadRegistros += 3;
            int intFila = 5;
            intColFactura = 2;
            intColPoliza = 4;
            intColMes = 5;
            intColGrupo = 6;
            intColEncontrado = 7;
            dirDirFacturas = new DirectoryInfo(strRutaFacturas);
            //Recorrer los datos
            recorrer = true;
            while (recorrer & (intFila<=intCantidadRegistros))
            {
                try
                {
                    strFactura = excelSheet.Cells[intFila, intColFactura].Value;
                    if (Object.ReferenceEquals(null, strFactura))
                    {
                        strFactura = "";
                    }

                    strMes = excelSheet.Cells[intFila, intColMes].Value;
                    if (Object.ReferenceEquals(null, strMes))
                    {
                        strMes = "";
                    }

                    strPoliza = excelSheet.Cells[intFila, intColPoliza].Value;
                    if (Object.ReferenceEquals(null, strPoliza))
                    {
                        strPoliza = "";
                    }

                    strGrupo = excelSheet.Cells[intFila, intColGrupo].Value.ToString();
                    if (Object.ReferenceEquals(null, strGrupo))
                    {
                        strGrupo = "";
                    }

                    try
                    {
                        strEncontrado = excelSheet.Cells[intFila, intColEncontrado].Value.ToString();
                        if (Object.ReferenceEquals(null, strEncontrado))
                        {
                            strEncontrado = "";
                        }
                    }
                    catch (Exception)
                    {
                        strEncontrado = "";
                    }
                    

                    if (strFactura.CompareTo("") != 0 & strMes.CompareTo("") != 0 & strPoliza.CompareTo("") != 0 & strGrupo.CompareTo("") != 0)
                    {
                        if (strEncontrado.CompareTo("") == 0 || strEncontrado.CompareTo("0") == 0)
                        {
                        //Busco el archivo por su nombre completo
                        fiArchivos = dirDirFacturas.GetFiles(strFactura + ".pdf", SearchOption.AllDirectories);
                        if (fiArchivos.Length > 0)
                        {
                            strRutaArchivo = fiArchivos[0].FullName.ToString();

                            strGrupoAux = strGrupo.Last().ToString();
                            strRutaActualSub = strRutaFacturasResultado + "\\" + strMes + "\\" + strGrupoAux + "\\" + strGrupo;
                            diDir = new DirectoryInfo(strRutaActualSub);

                            if (!diDir.Exists) //Si el directorio no existe, lo creo
                            {
                                diDir.Create();
                            }

                            strRutaAux = strRutaActualSub + "\\" + strPoliza + "_" + strFactura + ".pdf";
                            strRutaAuxPoliza = strRutaActualSub + "\\" + strPoliza + "_0.pdf";
                            if (!File.Exists(strRutaAux))
                            {
                                File.Copy(strRutaArchivo, strRutaAux);
                            }
                            excelSheet.Cells[intFila, intColEncontrado].Value = "1";
                                if (!File.Exists(strRutaAuxPoliza))
                                {
                                    DescargarPolizaPDF();
                                }
                            //recorrer = false;
                        }
                        else { excelSheet.Cells[intFila, intColEncontrado].Value = "0"; }
                        }
                    }

                    //Thread.Sleep(200);
                    intConteo++;
                    AumentarProgreso(((intConteo * 100) / (intCantidadRegistros-3)));
                    intFila++;
                }
                catch (Exception e)
                {
                    recorrer = false;
                    MessageBox.Show(e.ToString());
                }
            }

            //excelSheet.SaveAs(strRutaExcel);
            
            if (oXL != null)
            {
                oXL.Quit();
            }
            
            return Thread.CurrentThread;
        }

        void DescargarPolizaPDF()
        {
            try
            {
                if (strPoliza.StartsWith("TRA"))
                {
                    strPolizaBuscar = strPoliza.Substring(strPoliza.Length - 6, 6);
                    //strPolizaBuscar = strPoliza.Substring(7, 6);
                    webclient.DownloadFile("http://inspect.mht-jcv.com/html/Empleado/Polizas/pdfpolizasgsus.php?numPoliza=" + strPolizaBuscar, strRutaAuxPoliza);
                }
            }
            catch (Exception e)
            {
            }
            
        }
    }
}
